export class Print {
    constructor() {
        this.index = 0; 
    }

    next(item) { 
        return item[this.index++]
    }
}
