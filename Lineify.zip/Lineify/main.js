import {Print} from "./Lineify.js"
let array = [1,2,3,4]
let a = new Print()
console.log(a.next(array))